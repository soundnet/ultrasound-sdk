//
//  RSMIT.h
//
//  Created by Chih Liang on 2015-05-19.
//  Copyright (c) 2014-2015 Sun Tech Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


#pragma mark - RSMIT
typedef NS_ENUM(NSUInteger, RSMITStatus) {
    RSMITStatusStandby,
    RSMITStatusSending,
    RSMITStatusReceiving,
    RSMITStatusError
};

typedef NS_ENUM(NSUInteger, RSMITErrorType) {
    RSMITErrorIncorrectParameters,
    RSMITErrorUninitialized,
    RSMITErrorInvalidLicense,
    RSMIT2ErrorGetLicenseConnectionFailed,
    RSMIT2ErrorGetLicenseDecodeFailed,
    RSMITErrorBusy,
    RSMITErrorLicenseExpired
};

typedef NS_ENUM(NSUInteger, RSMITServerLocation) {
    RSMITServerGlobal,
    RSMITServerChina,
    RSMITServerHNA
};

@protocol RSMITDelegate;

@interface RSMIT : NSObject

@property (assign, nonatomic) id<RSMITDelegate> delegate;
@property (readonly, nonatomic) RSMITStatus status;

@property (strong, nonatomic) NSString *kMerID;
@property (strong, nonatomic) NSString *kApprovalCode;
@property (assign, nonatomic) RSMITServerLocation kServerLocation;

+ (instancetype)sharedController;

- (void)initialize;
- (BOOL)isInitialized;

- (void)startSendWithData:(NSString *)data;
- (void)stopSend;
- (void)startReceive;
- (void)stopReceive;

@end


@protocol RSMITDelegate <NSObject>

@required

- (void)mitErrorWithType:(RSMITErrorType)type errorMessage:(NSString *)errorMessage;
- (void)mitDidStartSend;
- (void)mitDidStopSend;
- (void)mitDidStartReceive;
- (void)mitDidStopReceive;
- (void)mitDidReceived:(NSString *)result;

@end
