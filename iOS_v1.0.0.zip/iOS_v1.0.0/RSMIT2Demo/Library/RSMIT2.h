//
//  RSMIT2.h
//
//  Created by Chih Liang on 2015-05-19.
//  Copyright (c) 2014-2015 Sun Tech Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma mark - RSMIT2

typedef NS_ENUM(NSUInteger, RSMIT2ErrorType) {
    RSMIT2ErrorIncorrectParameters,
    RSMIT2ErrorUninitialized,
    RSMIT2ErrorInitializeFailed,
    RSMIT2ErrorVerifyFailed,
    RSMIT2ErrorExpired,
    RSMIT2ErrorInvalidLicense,
    RSMIT2ErrorConnectionFailed,
    RSMIT2ErrorDecodeFailed
};

typedef NS_ENUM(NSUInteger, RSMIT2ServerLocation) {
    RSMIT2ServerGlobal,
    RSMIT2ServerChina,
    RSMIT2ServerHNA
};

@protocol RSMIT2Delegate;

@interface RSMIT2 : NSObject

@property (assign, nonatomic) id<RSMIT2Delegate> delegate;
@property (readonly, nonatomic) BOOL isReceiving;

@property (strong, nonatomic) NSString *kMerID;
@property (strong, nonatomic) NSString *kApprovalCode;
@property (assign, nonatomic) RSMIT2ServerLocation kServerLocation;

+ (instancetype)sharedController;

- (void)initialize;
- (BOOL)isInitialized;

- (void)startReceive;
- (void)stopReceive;

@end


@protocol RSMIT2Delegate <NSObject>

@required

- (void)mit2ErrorWithType:(RSMIT2ErrorType)type errorMessage:(NSString *)errorMessage;
- (void)mit2ReadyToReceive;
- (void)mit2DidStartReceive;
- (void)mit2DidStopReceive;
- (void)mit2DidReceived:(NSDictionary *)result;

@end
