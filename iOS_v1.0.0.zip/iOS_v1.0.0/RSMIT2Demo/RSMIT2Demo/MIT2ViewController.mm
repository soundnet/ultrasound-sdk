//
//  MIT2ViewController.m
//  RSMIT2Demo
//
//  Created by Chih Liang on 2015-05-20.
//  Copyright (c) 2014-2015 Sun Tech Co., Ltd. All rights reserved.
//

#import "MIT2ViewController.h"
#import "RSMIT2.h"

@interface MIT2ViewController () <RSMIT2Delegate>
@end

@implementation MIT2ViewController
{
    UIButton *actionButton;
    UITextView *statusView;
}

- (instancetype)init {
    self = [super init];
    
    if (self) {
        [self setTitle:@"遠距"];
        
        actionButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [actionButton setFrame:CGRectMake(20.0f, 84.0f, self.view.frame.size.width - 40.0f, 44.0f)];
        [actionButton setTitle:@"Start" forState:UIControlStateNormal];
        [actionButton setEnabled:NO];
        [actionButton addTarget:self action:@selector(actionButtonPressed) forControlEvents:UIControlEventTouchUpInside];
        
        statusView = [[UITextView alloc] initWithFrame:CGRectMake(10.0f, actionButton.frame.origin.y + actionButton.frame.size.height + 20.0f, self.view.frame.size.width - 20.0f, self.view.frame.size.height - (actionButton.frame.origin.y + actionButton.frame.size.height + 20.0f) - 20.0f - 49.0f)];
        [statusView setFont:[UIFont systemFontOfSize:14.0f]];
        [statusView setText:@""];
        [statusView setEditable:NO];
        [statusView setScrollEnabled:YES];
        [statusView setAlwaysBounceHorizontal:NO];
        [statusView setAlwaysBounceVertical:YES];
        [statusView.layer setCornerRadius:6.0f];
        [statusView.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
        [statusView.layer setBorderWidth:0.5f];
        
        if (NSFoundationVersionNumber < NSFoundationVersionNumber_iOS_7_0)
        {
            [actionButton setFrame:CGRectMake(actionButton.frame.origin.x, 20.0f, actionButton.frame.size.width, actionButton.frame.size.height)];
            [statusView setFrame:CGRectMake(statusView.frame.origin.x, actionButton.frame.origin.y + actionButton.frame.size.height + 20.0f, statusView.frame.size.width, self.view.frame.size.height - (actionButton.frame.origin.y + actionButton.frame.size.height + 20.0f) - 20.0f - 44.0f - 49.0f)];
        }
        else
        {
            [statusView setSelectable:NO];
        }
        
        [self.view setBackgroundColor:[UIColor whiteColor]];
        [self.view addSubview:actionButton];
        [self.view addSubview:statusView];
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    [[RSMIT2 sharedController] setDelegate:self];
    
    [[RSMIT2 sharedController] setKMerID:@"請輸入商家代碼"];
    [[RSMIT2 sharedController] setKApprovalCode:@"請輸入 API 授權碼"];
    [[RSMIT2 sharedController] setKServerLocation:RSMIT2ServerGlobal];
    
    if (![[RSMIT2 sharedController] isInitialized]) {
        [[RSMIT2 sharedController] initialize];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    if ([[RSMIT2 sharedController] isReceiving]) {
        [[RSMIT2 sharedController] stopReceive];
    }
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Custom Methods
- (void)actionButtonPressed {
    
    if ([[RSMIT2 sharedController] isReceiving]) {
        [[RSMIT2 sharedController] stopReceive];
    }else {
        [[RSMIT2 sharedController] startReceive];
    }
    
}

- (void)updateLog:(NSString *)message {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HH:mm:ss"];
    
    NSString *currentTime = [dateFormatter stringFromDate:[NSDate date]];
    
    NSMutableString *log = [[NSMutableString alloc] initWithString:currentTime];
    [log appendFormat:@"\n%@\n\n%@", message, statusView.text];
    
    [statusView setText:log];
}

#pragma mark - RSMIT2Delegate

- (void)mit2ErrorWithType:(RSMIT2ErrorType)type errorMessage:(NSString *)errorMessage {
    NSLog(@"mit2ErrorWithType %@",[NSString stringWithFormat:@"[ERROR] %lu %@", (unsigned long)type, errorMessage]);
    [self updateLog:[NSString stringWithFormat:@"[ERROR] %lu %@", (unsigned long)type, errorMessage]];
}

- (void)mit2DidReceived:(NSDictionary *)result {
    
    NSLog(@"received result dictionary %@",result);
    
    NSMutableString *resultString = [[NSMutableString alloc] initWithFormat:@"{\n"];
    
    for (NSString *key in result) {
        [resultString appendFormat:@"\t%@ = \"%@\";\n", key, [result objectForKey:key]];
    }
    
    [resultString appendFormat:@"}"];
    
    [self updateLog:[NSString stringWithFormat:@"DidReceived\n%@", resultString]];
}

- (void)mit2ReadyToReceive {
    [self updateLog:@"ReadyToReceive"];
    
    [actionButton setEnabled:YES];
}

- (void)mit2DidStartReceive {
    [self updateLog:@"DidStartReceive"];
    
    [actionButton setTitle:@"Stop" forState:UIControlStateNormal];
}

- (void)mit2DidStopReceive {
    [self updateLog:@"DidStopReceive"];
    
    [actionButton setTitle:@"Start" forState:UIControlStateNormal];
}

- (void)mit2InitializedFailed:(NSString *)message {
    [self updateLog:[NSString stringWithFormat:@"InitializedFailed %@", message]];
}

@end
