//
//  MITViewController.m
//  RSMIT2Demo
//
//  Created by Chih Liang on 2015-06-30.
//  Copyright (c) 2015 Sun Tech Co., Ltd. All rights reserved.
//

#import "MITViewController.h"
#import "RSMIT.h"

@interface MITViewController () <UITextViewDelegate, RSMITDelegate>
@end

@implementation MITViewController
{
    UIButton *sendButton;
    UIButton *receiveButton;
    UITextView *sendTextView;
    UITextView *receiveTextView;
}

- (instancetype)init
{
    self = [super init];
    
    if (self)
    {
        [self setTitle:@"近場"];
        
        UIButton *randomButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [randomButton setFrame:CGRectMake(10.0f, (NSFoundationVersionNumber < NSFoundationVersionNumber_iOS_7_0) ? 10.0f : 74.0f, (self.view.frame.size.width - 30.0f) / 2, 44.0f)];
        [randomButton setTitle:@"Random" forState:UIControlStateNormal];
        [randomButton addTarget:self action:@selector(actionRandom) forControlEvents:UIControlEventTouchUpInside];
        
        sendButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [sendButton setFrame:CGRectMake(randomButton.frame.origin.x + randomButton.frame.size.width + 10.0f, randomButton.frame.origin.y, randomButton.frame.size.width, randomButton.frame.size.height)];
        [sendButton setTitle:@"Start Send" forState:UIControlStateNormal];
        [sendButton addTarget:self action:@selector(actionSend) forControlEvents:UIControlEventTouchUpInside];
        
        CGFloat textViewHeight = (self.view.frame.size.height - randomButton.frame.origin.y - randomButton.frame.size.height - 40.0f - 44.0f - 49.0f) / 2;
        
        if (NSFoundationVersionNumber < NSFoundationVersionNumber_iOS_7_0)
        {
            textViewHeight -= 24.0f;
        }
        
        sendTextView = [[UITextView alloc] initWithFrame:CGRectMake(10.0f, randomButton.frame.origin.y + randomButton.frame.size.height + 10.0f, self.view.frame.size.width - 20.0f, 50.0f)];
        [sendTextView setDelegate:self];
        [sendTextView setBackgroundColor:[UIColor clearColor]];
        [sendTextView setFont:[UIFont systemFontOfSize:14.0f]];
        [sendTextView setText:@""];
        [sendTextView setEditable:YES];
        [sendTextView setReturnKeyType:UIReturnKeyDone];
        [sendTextView setScrollEnabled:YES];
        [sendTextView setAlwaysBounceHorizontal:NO];
        [sendTextView setAlwaysBounceVertical:YES];
        [sendTextView.layer setCornerRadius:6.0f];
        [sendTextView.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
        [sendTextView.layer setBorderWidth:0.5f];
        
        receiveButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [receiveButton setFrame:CGRectMake(10.0f, sendTextView.frame.origin.y + sendTextView.frame.size.height + 10.0f, self.view.frame.size.width - 20.0f, 44.0f)];
        [receiveButton setTitle:@"Start Receive" forState:UIControlStateNormal];
        [receiveButton addTarget:self action:@selector(actionReceive) forControlEvents:UIControlEventTouchUpInside];
        
        receiveTextView = [[UITextView alloc] initWithFrame:CGRectMake(10.0f, receiveButton.frame.origin.y + receiveButton.frame.size.height + 10.0f, receiveButton.frame.size.width, (textViewHeight * 2) - 50.0f)];
        [receiveTextView setBackgroundColor:[UIColor clearColor]];
        [receiveTextView setDelegate:self];
        [receiveTextView setFont:[UIFont systemFontOfSize:14.0f]];
        [receiveTextView setText:@""];
        [receiveTextView setEditable:NO];
        [receiveTextView setReturnKeyType:UIReturnKeyDone];
        [receiveTextView setScrollEnabled:YES];
        [receiveTextView setAlwaysBounceHorizontal:NO];
        [receiveTextView setAlwaysBounceVertical:YES];
        [receiveTextView.layer setCornerRadius:6.0f];
        [receiveTextView.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
        [receiveTextView.layer setBorderWidth:0.5f];
        
        UIButton *hideButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [hideButton setFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height)];
        [hideButton setBackgroundColor:[UIColor clearColor]];
        [hideButton addTarget:self action:@selector(actionHideKeyboard) forControlEvents:UIControlEventTouchUpInside];
        
        [self.view setBackgroundColor:[UIColor whiteColor]];
        [self.view addSubview:hideButton];
        [self.view addSubview:randomButton];
        [self.view addSubview:sendTextView];
        [self.view addSubview:sendButton];
        [self.view addSubview:receiveButton];
        [self.view addSubview:receiveTextView];
        
        [self actionRandom];
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [[RSMIT sharedController] setDelegate:self];
    
    [[RSMIT sharedController] setKMerID:@"請輸入商家代碼"];
    [[RSMIT sharedController] setKApprovalCode:@"請輸入 API 授權碼"];
    [[RSMIT sharedController] setKServerLocation:RSMITServerGlobal];
    
    if (![[RSMIT sharedController] isInitialized]) {
        [[RSMIT sharedController] initialize];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if ([[RSMIT sharedController] status] == RSMITStatusSending)
    {
        [[RSMIT sharedController] stopSend];
    }
    
    if ([[RSMIT sharedController] status] == RSMITStatusReceiving)
    {
        [[RSMIT sharedController] stopReceive];
    }
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Custom Methods

- (void)actionHideKeyboard
{
    if ([sendTextView isFirstResponder])
    {
        [sendTextView resignFirstResponder];
    }
}

- (void)actionRandom
{
    [self actionHideKeyboard];
    
    NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString *dataString = [[NSMutableString alloc] init];
    NSUInteger letterLength = [letters length];
    NSUInteger dataLength = 30;
    
    for (NSUInteger i = 0; i < dataLength; i++)
    {
        if (i < dataLength)
        {
            [dataString appendFormat:@"%C", [letters characterAtIndex:arc4random() % letterLength]];
        }
    }
    
    [sendTextView setText:dataString];
}

- (void)actionSend
{
    [self actionHideKeyboard];
    
    if ([[RSMIT sharedController] status] == RSMITStatusSending)
    {
        [[RSMIT sharedController] stopSend];
    }
    else
    {
        [[RSMIT sharedController] startSendWithData:sendTextView.text];
    }
}

- (void)actionReceive
{
    [self actionHideKeyboard];
    
    if ([[RSMIT sharedController] status] == RSMITStatusReceiving)
    {
        [[RSMIT sharedController] stopReceive];
    }
    else
    {
        [[RSMIT sharedController] startReceive];
    }
}

- (void)updateLog:(NSString *)message
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HH:mm:ss"];
    
    NSString *currentTime = [dateFormatter stringFromDate:[NSDate date]];
    
    NSMutableString *log = [[NSMutableString alloc] initWithString:currentTime];
    [log appendFormat:@"\n%@\n\n%@", message, receiveTextView.text];
    
    [receiveTextView setText:log];
}

#pragma mark - UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        
        return NO;
    }
    else
    {
        return YES;
    }
}

#pragma mark - RSMITDelegate

- (void)mitErrorWithType:(RSMITErrorType)type errorMessage:(NSString *)errorMessage {
    NSLog(@"mitErrorWithType %@",[NSString stringWithFormat:@"[ERROR] %lu %@", (unsigned long)type, errorMessage]);
    [self updateLog:[NSString stringWithFormat:@"[ERROR] %lu %@", (unsigned long)type, errorMessage]];
}

- (void)mitDidStartSend
{
    [self updateLog:@"DidStartSend"];
    
    [sendButton setTitle:@"Stop Send" forState:UIControlStateNormal];
    
    [receiveButton setEnabled:NO];
}

- (void)mitDidStopSend
{
    [self updateLog:@"DidStopSend"];
    
    [sendButton setTitle:@"Start Send" forState:UIControlStateNormal];
    
    [receiveButton setEnabled:YES];
}

- (void)mitDidStartReceive
{
    [self updateLog:@"DidStartReceive"];
    
    [receiveButton setTitle:@"Stop Receive" forState:UIControlStateNormal];
    
    [sendButton setEnabled:NO];
}

- (void)mitDidStopReceive
{
    [self updateLog:@"DidStopReceive"];
    
    [receiveButton setTitle:@"Start Receive" forState:UIControlStateNormal];
    
    [sendButton setEnabled:YES];
}

- (void)mitDidReceived:(NSString *)result
{
    [self updateLog:[NSString stringWithFormat:@"DidReceived\n%@", result]];
}

@end
