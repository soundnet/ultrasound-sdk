//
//  AppDelegate.h
//  RSMIT2Demo
//
//  Created by Chih Liang on 2015-05-20.
//  Copyright (c) 2014-2015 Sun Tech Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

