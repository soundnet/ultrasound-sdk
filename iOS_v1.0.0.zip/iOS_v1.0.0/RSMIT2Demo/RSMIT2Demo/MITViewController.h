//
//  MITViewController.h
//  RSMIT2Demo
//
//  Created by Chih Liang on 2015-06-30.
//  Copyright (c) 2015 Sun Tech Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MITViewController : UIViewController

@end
